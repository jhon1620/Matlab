# SOURCE CODE TUTORIAL ALGORTIMA GENETIKA

## Episode 0 - Pendahuluan tentang apa itu algoritma genetika
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/2mXcs-CNCB8/0.jpg)](https://www.youtube.com/watch?v=2mXcs-CNCB8)
