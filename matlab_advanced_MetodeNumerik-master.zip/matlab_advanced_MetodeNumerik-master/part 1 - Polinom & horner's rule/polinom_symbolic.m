clear
clc

% p(x)  = x^2 + 2*x + 5

x = sym('x');
p1(x) = x^2 + 2*x + 5;
p2(x) = 2*x^2 + 3*x + 6;

p3(x) = 10 + 11*x + 12*x^2 + 127*x^3;