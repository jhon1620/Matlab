clear
clc


Mahasiswa = struct();

Mahasiswa(1).nama = 'Otong';
Mahasiswa(1).NIM = 14045123;
Mahasiswa(1).jurusan = 'teknik tata busana';
Mahasiswa(1).nilai.kalkulus = 80;
Mahasiswa(1).nilai.fisika = 75;
Mahasiswa(1).nilai.menjait = 100;

Mahasiswa(2).nama = 'Ucup';
Mahasiswa(2).NIM = 14045124;
Mahasiswa(2).jurusan = 'teknik tata boga';
Mahasiswa(2).nilai.kalkulus = 60;
Mahasiswa(2).nilai.fisika = 75;
Mahasiswa(2).nilai.memasak = 100;