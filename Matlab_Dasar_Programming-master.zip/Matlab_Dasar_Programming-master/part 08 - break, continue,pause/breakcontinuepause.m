clear
clc

for i=1:20
   
   if i==10
       disp('angka 10 ditemukan');
       continue
   end
   pause(0.1);
   disp(i);
end

disp('akhir dari looping');